from flask import Flask, session, redirect, url_for, escape, request
from werkzeug import secure_filename
from flask import render_template
from milkseeker import planisphere


app = Flask(__name__)

@app.route("/")
def index():
    # this is used to "setup" the session with starting values
    session['room_name'] = planisphere.START
    session['user_score'] = 0
    session['other_score'] = 0
    session['previous_user_move'] = None
    session['previous_other_move'] = None
    session['invalid_input'] = 0
    planisphere.refresh_quip()
    return redirect(url_for("game"))

# handles links to localhost:5000/game for both 'GET' and 'POST'
@app.route("/game", methods=['GET','POST'])
def game():
    # get the room_name variable from the session and store as local variable
    room_name = session.get('room_name')
    entrance_name = session.get('entrance_name')
    invalid_input = session.get('invalid_input')

    # if it did not come from the html form
    if request.method == "GET":
        # test if room_name exists
        if room_name:
            # if it does, get the room object from planisphere
            room = planisphere.load_room(room_name)
            if entrance_name:
                entrance_text = room.entrance.get(entrance_name)
                # push html page with room data
                if room_name == 'fridge':
                    return render_template("show_room.html",room=room,entrance=entrance_text,
                        user_move=session['previous_user_move'],
                        other_move=session['previous_other_move'],
                        user_score=session['user_score'],
                        other_score=session['other_score'],
                        invalid_input=invalid_input)
                return render_template("show_room.html",room=room,entrance=entrance_text,invalid_input=invalid_input)
            else:
                return render_template("show_room.html",room=room,invalid_input=invalid_input)
        else:
            # why is this here? do you need it?
            # it is here in case localhost:5000/game is typed in without
            # any previous game session
            return render_template("you_died.html")
    # if it did come from the html form via 'POST'
    else:
        # get the user input from the form, lowercase, split into words, store as 'action'
        action = request.form.get('action').lower().split(' ')

        # test if room_name exists and action exists
        if room_name and action:
            # check if post request is coming from 'fridge' room
            if room_name == 'fridge':
                # get user move, make sure it's valild
                your_move = planisphere.rps_parse_input(action)
                if your_move != '__invalid__':
                    # input is valid
                    session['invalid_input'] = 0
                    # get random move from planisphere
                    other_move = planisphere.rps_random()
                    # compare user move with random move, store as -1,0,1 in session
                    session['previous_outcome'] = planisphere.rps_compare(your_move, other_move)
                    session['previous_user_move'] = your_move
                    session['previous_other_move'] = other_move
                    # if other move wins, increment other score
                    if session['previous_outcome'] == -1:
                        session['other_score'] += 1
                    # if user move wins, increment user score
                    elif session['previous_outcome'] == 1:
                        session['user_score'] += 1
                    else:
                        pass
                    # check if other has won
                    if session['other_score'] == 2:
                    # if so, set action to lose
                        action = ['user_lose']
                    # check if user has won
                    elif session['user_score'] == 2:
                    # if so, set action to win
                        action = ['user_win']
                    else:
                        action = ['continue']
            # if it does, get the room object from planisphere
            room = planisphere.load_room(room_name)
            # use the room object to pass in the 'go' method using the
            # user's input as a parameter,
            # assigning the 'next' room as next_room (room object)
            next_room = match_path(action, room)

            # if 'match_paths' method didn't match anything
            if not next_room:
                # get back the original room name (String), and assign the
                # 'room_name' variable in session
                # set invalid_input tag
                session['invalid_input'] = 1
                session['room_name'] = planisphere.name_room(room)
            # if 'go' method matched a room
            else:
                # get the String name of 'next_room' and assign it to the
                # 'room_name' variable in session
                # remove invalid_input tag
                session['invalid_input'] = 0
                session['room_name'] = planisphere.name_room(next_room)

        # run the /game page again, as a 'GET' method
        return redirect(url_for("game"))

def match_path(words, room):
    for i in words:
        if room.go(i):
            session['entrance_name'] = i
            return room.go(i)

# YOU SHOULD CHANGE THIS IF YOU PUT ON THE INTERNET
app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'

if __name__=='__main__':
    app.run()
