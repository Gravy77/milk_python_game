import random
from random import randint

class Room(object):

    def __init__(self, name, entrance, description):
        self.name = name
        self.entrance = entrance
        self.description = description
        self.paths = {}

    def go(self, direction):
        return self.paths.get(direction, None)

    def add_paths(self, paths):
        self.paths.update(paths)

car = Room("Car",{},
"""
You ran out of milk.  If you don’t buy some before the store closes, you won’t
have milk for your cereal in the morning.  You cannot function without your
morning cereal.

You get in your car, turn the key and the engine sputters. It won't start!
""")

parking_lot = Room("Parking Lot",
{
'jump':
"""
With some quick thinking, you ask your neighbor to jump start your car.
He is happy to help you. Once started, you head off to the grocery store.
""",
'aaa':
"""
You are prepared for such a vehicular setback with your AAA membership.
You call them, and sure enough, a service truck arrives in minutes to
replace your battery. Once working, you head off to the store.
""",
'try':
"""
A small hindrance has never held you back. You don't give up. You keep trying and trying the
ignition. Eventually, the car hums, starts up, and you are on your way to the store.
""",
'another car':
"""
You decide to take another car. This one is working perfectly, and you drive to the store.
"""
},
"""
You arrive at the grocery store. It's busy. All parking spots are occupied.
Just as a car is leaving you and a blue SUV signal simultaneously.
This could get nasty...
""")

fridge = Room("Fridge", {
'let':
"""
You know your manners, so you wave to let the blue SUV take the spot.
The driver in the SUV appreciates your kindness. She reciprocates and lets you park.

You enter the store.
""",
'talk':
"""
You get out of your car to explain to the other driver that you can't start
your day without milk and cereal. She understands your pain and lets you take the spot.
""",
'wait':
"""
Patience is a virtue. You give up the spot and wait for another. Sure enough,
another person leaves. You are able to park and go inside.
"""
},
"""
You arrive at the milk section. There is one carton left. You reach for it at
the same time as an old lady. As mature adults, the two of you agree to play
rock-paper-scissors for it. It's best two out of three.
""")

cashier = Room("Cashier",{},
"""
Incredibly, you won the match of rock/paper/scissors! You happily pick up the
last carton of milk, and head to the cashier.

You get in line at the cashier. You notice something is dripping. The milk
carton has a hole in it. You must act quickly or the entire carton will end
up on the floor.
""")

finished = Room("Finished",{
'tape':
"""
You rush to the hardware aisle and grab tape. You apply some tape to the hole.
It's not pretty, but the leak has stopped. Crisis averted. You pay for your goods
and head home. Success!
""",
'bag':
"""
You ask the cashier for a plastic bag. You put the carton in the bag and tie it up.
Some milk is dripping into the bag, but at least it's contained. Your resourcefulness
has proven worthy.
""",
'tilt':
"""
You calmly tilt the carton up vertically so that the hole is facing upwards.
Nothing to worry about. A bit of care on the way home and you've got your milk!
"""
},
"""
You have successfully bought milk. Good job!
""")

lost = Room("Lost",{
'bus':
"""
You decide to take the bus. You get to the bus stop and wait. And wait. And wait.
By the time the bus arrives, the store has closed and you lost your chance.
""",
'walk':
"""
You decide to walk. As you're walking, you accidentally slip off the curb and
twist your ankle. You have no choice but to give up.
""",
'illegal':
"""
Since it will take only a few minutes, you decide to park illegally. You go in the
store. Just as you get inside, a parking agent walks up and writes a ticket.
You run outside and apologize, but it's too late. Angry about the ticket, you
decide to go back home.
""",
'park':
"""
It's every man for himself. You slam on the gas and race
to the spot. Your brazen decision gets you there first.

BANG!!

You lost sight of the parked car on the other side and smack
into it! The car alarm goes off. Everybody is watching.
Frozen by shame and humiliation, you are unable to go in
the store.
""",
'drink':
"""
You decide to drink the milk. After some effort, you've finished!
However, now you have no milk for tomorrow...
""",
'user_lose':
"""
Unfortunately, you were no match for the old lady.
"""
},

""

)

car.add_paths({
    'jump': parking_lot,
    'aaa' : parking_lot,
    'try' : parking_lot,
    'another car' : parking_lot,
    'bus' : lost,
    'walk' : lost
})

parking_lot.add_paths({
    'wait' : fridge,
    'let' : fridge,
    'talk' : fridge,
    'illegal' : lost,
    'park' : lost
})

fridge.add_paths({
    'user_win' : cashier,
    'user_lose' : lost,
    'continue' : fridge
})

cashier.add_paths({
    'tape' : finished,
    'bag' : finished,
    'tilt' : finished,
    'drink' : lost
})

START = 'car'

def load_room(name):
    """
    There is a potential security problem here.
    Who gets to set name? Can that expose a variable?
    """
    return globals().get(name)

def name_room(room):
    """
    Same possible security problem.Can you trust room?
    What's a better solution than this globals lookup?
    """
    for key, value in globals().items():
        if value == room:
            return key

def rps_random():
    move = randint(1,3)
    if move == 1:
        return "rock"
    elif move == 2:
        return "paper"
    else:
        return "scissors"

# takes the action list input and returns rock/paper/scissors/invalid
def rps_parse_input(input):
    for i in input:
        if i in ["rock", "paper", "scissors"]:
            return i
    return "__invalid__"

# compare user move with other move, return win (1), lose(-1), tie(0)
def rps_compare(user_move, other_move):
    if other_move == user_move:
        return 0
    elif other_move == "rock":
        if user_move == "paper":
            return 1
        else:
            return -1
    elif other_move == "paper":
        if user_move == "rock":
            return -1
        else:
            return 1
    else:
        if user_move == "rock":
            return 1
        else:
            return -1

def refresh_quip():
    lost.description = random.choice([
        "You lost. Maybe this is too hard for you",
        "You couldn't even buy milk. Where did it all go wrong?",
        "You failed to get milk. It's time to pack it all up live in the woods.",
        "Milk eludes you. You wonder if you'll ever see milk again.",
        "No milk for you. What did you do to deserve this?"
    ])
